package common;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferencesService
{
    public static final String ENABLE_MEMORY_KEY = "settingsEnableMemory";
    public static final String MEMORY_COUNT_KEY = "settingsMemoryCount";
    private Activity a;

    public SharedPreferencesService(Activity activity) {
        a = activity;
    }

    public void saveBoolean(final boolean isChecked, String key) {
        SharedPreferences sharedPreferences = a.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(key, isChecked);
        editor.apply();
    }

    public void saveInteger(final int iValue, String key) {
        SharedPreferences sharedPreferences = a.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(key, iValue);
        editor.apply();
    }

    public boolean loadBoolean(String key) {
        SharedPreferences sharedPreferences = a.getPreferences(Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(key, false);
    }

    public int loadInteger(String key) {
        SharedPreferences sharedPreferences = a.getPreferences(Context.MODE_PRIVATE);
        return sharedPreferences.getInt(key, 0);
    }


    public int getMemorySize() {
        return loadInteger(MEMORY_COUNT_KEY);
    }

    public boolean isMemoryEnabled() {
        return loadBoolean(ENABLE_MEMORY_KEY);
    }


}

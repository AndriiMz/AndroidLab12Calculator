package common;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Array;

public class LocalHistoryService {
    private static final String HISTORY_FILE = "ch.txt";
    private Activity a;

    public LocalHistoryService(Activity activity) {
        a = activity;
    }

    public void clear() {
        try {
            FileOutputStream fileOut = a.openFileOutput(HISTORY_FILE, Context.MODE_PRIVATE);
            OutputStreamWriter writer = new OutputStreamWriter(fileOut);
            writer.write("");
            writer.close();

        } catch (Exception e) {
            // e.printStackTrace();
        }
    }

    public void write(String line, int storageSize) {
        String stored = read();
        if(stored.length() == 0) {
            stored = line;
        } else {
            stored += "," + line;
        }

        String[] sArray = TextUtils.split(stored, ",");
        if(sArray.length > storageSize) {
            stored = "";
        }

        try {
            FileOutputStream fileOut = a.openFileOutput(HISTORY_FILE, Context.MODE_PRIVATE);
            OutputStreamWriter writer = new OutputStreamWriter(fileOut);
            writer.write(stored);
            writer.close();

        } catch (Exception e) {
           // e.printStackTrace();
        }
    }


    public String read() {
        try {
            FileInputStream file = a.openFileInput(HISTORY_FILE);
            InputStreamReader reader = new InputStreamReader(file);
            char[] buffer = new char[1000];
            String s = "";
            int read;
            while ((read = reader.read(buffer)) > 0) {
                // char to string conversion
                String rs = String.copyValueOf(buffer, 0, read);
                s += rs;
            }
            reader.close();
            return s;
        } catch (Exception e) {
            return "";
        }
    }
}

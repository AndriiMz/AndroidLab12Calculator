package pwr.swim.lab12;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.ActionMode;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;

import common.LocalHistoryService;
import common.SharedPreferencesService;
import pwr.swim.lab12.databinding.ActivityDashboardBinding;

public class Dashboard extends AppCompatActivity {
    private static final char ADD = '+';
    private static final char SUB = '-';
    private static final char MUL = '*';
    private static final char DIV = '/';
    private static final char SIN = 's';
    private static final char COS = 'c';
    private char ACTION;

    private ActivityDashboardBinding binding;
    private DecimalFormat outputFormat;
    private LocalHistoryService history;
    private SharedPreferencesService preferencesService;
    private double argument1 = Double.NaN;
    private double argument2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_dashboard);

        outputFormat = new DecimalFormat("#.##########");
        history = new LocalHistoryService(this);
        preferencesService = new SharedPreferencesService(this);
        BottomNavigationView bottomNavigationView = (BottomNavigationView)
                findViewById(R.id.navigation);

        bindNumberButtonClick(binding.buttonZero, "0");
        bindNumberButtonClick(binding.buttonOne, "1");
        bindNumberButtonClick(binding.buttonTwo, "2");
        bindNumberButtonClick(binding.buttonThree, "3");
        bindNumberButtonClick(binding.buttonFour, "4");
        bindNumberButtonClick(binding.buttonFive, "5");
        bindNumberButtonClick(binding.buttonSix, "6");
        bindNumberButtonClick(binding.buttonSeven, "7");
        bindNumberButtonClick(binding.buttonEight, "8");
        bindNumberButtonClick(binding.buttonNine, "9");
        bindNumberButtonClick(binding.buttonNine, ".");

        binding.buttonEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                computeCalculation();
                String results =  binding.infoTextView.getText().toString();
                if(argument2 != Double.NaN) {
                    results += outputFormat.format(argument2);
                }
                results += " = " + outputFormat.format(argument1);
                binding.infoTextView.setText(results);
                _writeHistory(results);
                argument1 = Double.NaN;
                ACTION = '0';
            }
        });

        binding.buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                argument1 = Double.NaN;
                argument2 = Double.NaN;
                binding.infoTextView.setText(null);
                binding.editText.setText(null);
                ACTION = '0';
            }
        });



        bottomNavigationView.setOnNavigationItemSelectedListener
                (new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.menuPlus:
                                computeCalculation();
                                ACTION = ADD;
                                if(argument1 != Double.NaN) {
                                    binding.infoTextView.setText(outputFormat.format(argument1) + ADD);
                                }
                                binding.editText.setText(null);
                                break;
                            case R.id.menuMinus:
                                computeCalculation();
                                ACTION = SUB;
                                if(argument1 != Double.NaN) {
                                    binding.infoTextView.setText(outputFormat.format(argument1) + SUB);
                                }
                                binding.editText.setText(null);
                                break;
                            case R.id.menuMultiple:
                                computeCalculation();
                                ACTION = MUL;
                                if(argument1 != Double.NaN) {
                                    binding.infoTextView.setText(outputFormat.format(argument1) + MUL);
                                }
                                binding.editText.setText(null);
                                break;
                            case R.id.menuDivision:
                                computeCalculation();
                                ACTION = DIV;
                                if(argument1 != Double.NaN) {
                                    binding.infoTextView.setText(outputFormat.format(argument1) + DIV);
                                }
                                binding.editText.setText(null);
                                break;
                        }
                        return true;
                    }
                });

        Button btn = (Button)findViewById(R.id.buttonContext);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActionMode(actionModeInterface);
            }
        });

        TextView textView = (TextView)findViewById(R.id.infoTextView);
        registerForContextMenu(textView);
    }

    protected void bindNumberButtonClick(Button button, final String additional) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + additional);
            }
        });
    }

    private void computeCalculation() {
        if(!Double.isNaN(argument1)) {
            if(ACTION != SIN && ACTION !=COS) {
                argument2 = Double.parseDouble(binding.editText.getText().toString());
                binding.editText.setText(null);
                if (ACTION == ADD)
                    argument1 = this.argument1 + argument2;
                else if (ACTION == SUB)
                    argument1 = this.argument1 - argument2;
                else if (ACTION == MUL)
                    argument1 = this.argument1 * argument2;
                else if (ACTION == DIV)
                    argument1 = this.argument1 / argument2;
            }
        } else {
            try {
                argument1 = Double.parseDouble(binding.editText.getText().toString());
            }
            catch (Exception e){}
        }
    }

//    public void runHistory(View view) {
//        final Intent h = new Intent("calculator.action.HISTORY");
//        startActivity(h);
//    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) {
            switch (resultCode) {
                case Activity.RESULT_OK:
                    Toast.makeText(getApplicationContext(), "Ustawienia zapisano!", Toast.LENGTH_SHORT).show();
                    break;
                case Activity.RESULT_CANCELED:
                    Toast.makeText(getApplicationContext(), "Ustawienia nie zapisano!", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.calculator_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuHistory:
                final Intent h = new Intent("calculator.action.HISTORY");
                startActivity(h);
                return true;
            case R.id.menuSettings:
                final Intent settingsWindow = new Intent(this, Settings.class);
                startActivityForResult(settingsWindow, 100);
                return true;
            case R.id.menuLike:
                item.setChecked(!item.isChecked());
                return true;
            case R.id.menuAbout:
                final Intent aboutWindow = new Intent(this, About.class);
                startActivityForResult(aboutWindow, 100);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        switch (v.getId()) {
            case R.id.infoTextView:
                menu.add(0, 0, 0, "Wyczyść");
                break;
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        // TODO Auto-generated method stub
        switch (item.getItemId()) {
            case 0:
                argument1 = Double.NaN;
                argument2 = Double.NaN;
                binding.infoTextView.setText(null);
                binding.editText.setText(null);
                ACTION = '0';
                break;
        }
        return  false;
    }

    private void _writeHistory(String line) {
        if(true) { //preferencesService.isMemoryEnabled() //TODO: fix service
            history.write(line, 10); //preferencesService.getMemorySize()
        } else {
            history.clear();
        }
    }

    private ActionMode.Callback actionModeInterface = new ActionMode.Callback() {

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.sin_cos_menu, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            switch (item.getItemId()) {
                case R.id.menuSin:
                    computeCalculation();
                    ACTION = SIN;
                    if(argument1 != Double.NaN) {
                        binding.infoTextView.setText("sin(" + outputFormat.format(argument1) + ")");
                    }
                    binding.editText.setText(null);
                case R.id.menuCos:
                    computeCalculation();
                    ACTION = COS;
                    if(argument1 != Double.NaN) {
                        binding.infoTextView.setText("cos(" + outputFormat.format(argument1) + ")");
                    }
                    binding.editText.setText(null);
                default:
                    return false;
            }
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {

        }
    };
}

package pwr.swim.lab12;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class About extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        View window2 = (View)findViewById(R.id.textView);
        window2.setOnLongClickListener(new View.OnLongClickListener(){
            public boolean onLongClick(View v) {
                finish();
                return false;
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        menu.add(Menu.NONE, 0, 0, "Condition and policy");
        menu.add(Menu.NONE, 1, 1, "Nasze aplikacji");
        return true;
    }

    public void runBack(View view) {
        finish();
    }

    /**
     * @param view
     */
    public void runWebPage(View view) {
        String url = "http://eportal.pwr.edu.pl/";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }

    public void runQuestions(View view) {
        final Intent questionsWindow = new Intent(this, Questions.class);
        startActivity(questionsWindow);
    }


    public void runDevelopers(View view) {
        final Intent devWindow = new Intent(this, Developers.class);
        startActivity(devWindow);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 0:
                final Intent conditionPolicyWindow = new Intent(this, ConditionPolicyActivity.class);
                startActivity(conditionPolicyWindow);
                return true;
            case 1:
                final Intent softwareWindow = new Intent(this, SoftwareActivity.class);
                startActivity(softwareWindow);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}

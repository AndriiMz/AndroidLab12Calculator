package pwr.swim.lab12;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class Questions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        Spinner spinner = (Spinner)findViewById(R.id.spinner);
        List<String> categories = new ArrayList<String>();
        categories.add("1 godzina ");
        categories.add("2 godziny");
        categories.add("4 godziny");
        categories.add("10 godzin");
        categories.add("20 godzin");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
    }

    public void runClose(View view) {
        finish();
    }
}

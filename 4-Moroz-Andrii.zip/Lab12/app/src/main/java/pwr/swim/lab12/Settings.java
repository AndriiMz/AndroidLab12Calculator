package pwr.swim.lab12;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import common.SharedPreferencesService;

public class Settings extends AppCompatActivity {


    private SharedPreferencesService memoryService;
    private ToggleButton tBtn;
    private SeekBar sBar;
    private TextView seekText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        memoryService = new SharedPreferencesService(this);
        tBtn = (ToggleButton)findViewById(R.id.toggleButton);
        tBtn.setChecked(memoryService.loadBoolean(SharedPreferencesService.ENABLE_MEMORY_KEY));

        int memoryCount = memoryService.loadInteger(SharedPreferencesService.MEMORY_COUNT_KEY);
        sBar = (SeekBar)findViewById(R.id.seekBar);
        sBar.setProgress(memoryCount);
        seekText = (TextView)findViewById(R.id.textView4);
        seekText.setText("" + memoryCount);
        sBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int memoryCountTmp = 0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progresValue, boolean fromUser) {
                memoryCountTmp = progresValue;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                seekText.setText("" + memoryCountTmp);
            }
        });
    }

    public void runCancel(View view) {
        Intent returnIntent = new Intent();
        setResult(Activity.RESULT_CANCELED, returnIntent);
        finish();
    }

    public void runSave(View view) {
        memoryService.saveBoolean(tBtn.isChecked(), SharedPreferencesService.ENABLE_MEMORY_KEY);
        memoryService.saveInteger(sBar.getProgress(), SharedPreferencesService.MEMORY_COUNT_KEY);

        Intent returnIntent = new Intent();
        setResult(Activity.RESULT_OK, returnIntent);
        finish();
    }
}

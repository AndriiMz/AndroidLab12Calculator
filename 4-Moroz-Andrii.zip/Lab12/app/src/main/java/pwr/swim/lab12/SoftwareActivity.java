package pwr.swim.lab12;

import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SoftwareActivity extends AppCompatActivity implements SoftwareSelectFragment.OnOptionSelect {

    private static final String TAG_MC = "FragmentMealCalc";
    private static final String TAG_HC = "FragmentHealthCalc";

    private boolean savedInstanceState;

    MealCalculatorFragment fMealCalc;
    HealthCalculatorFragment fHealthCalc;
    FragmentTransaction transaction;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_software);


        if(savedInstanceState == null) {
            fMealCalc = new MealCalculatorFragment();
            fHealthCalc = new HealthCalculatorFragment();
            transaction = getSupportFragmentManager().beginTransaction();
            transaction.add(R.id.softwareContainer, fMealCalc, SoftwareActivity.TAG_MC);
            transaction.detach(fMealCalc);
            transaction.add(R.id.softwareContainer, fHealthCalc, SoftwareActivity.TAG_HC);
            transaction.detach(fHealthCalc);
            transaction.commit();
        } else {
            fMealCalc = (MealCalculatorFragment)getSupportFragmentManager().findFragmentByTag(SoftwareActivity.TAG_MC);
            fHealthCalc = (HealthCalculatorFragment)getSupportFragmentManager().findFragmentByTag(SoftwareActivity.TAG_HC);
        }
    }

    @Override
    public void onOptionSelect(int option) {
        FragmentTransaction transact = getSupportFragmentManager().beginTransaction();
        switch (option) {
            case 1:
                transact.detach(fHealthCalc);
                transact.attach(fMealCalc);
                break;
            case 2:
                transact.detach(fMealCalc);
                transact.attach(fHealthCalc);
                break;
            default:
                break;
        }
        transact.commit();
    }
}

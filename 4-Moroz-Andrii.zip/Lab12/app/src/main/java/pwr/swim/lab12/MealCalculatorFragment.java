package pwr.swim.lab12;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Switch;

import common.SharedPreferencesService;

/**
 * A simple {@link Fragment} subclass.
 */
public class MealCalculatorFragment extends Fragment {

    private SharedPreferencesService sp;
    private Switch sw;

    public MealCalculatorFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        setRetainInstance(true);
        View view = inflater.inflate(R.layout.fragment_meal_calculator, container, false);
        Button button = (Button)view.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String url = "http://eportal.pwr.edu.pl/";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        sp = new SharedPreferencesService(this.getActivity());
        sw = (Switch) view.findViewById(R.id.switchMeal);
        sw.setChecked(sp.loadBoolean("switchMeal"));

        return view;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        sp.saveBoolean(sw.isChecked(), "switchMeal");
    }

}

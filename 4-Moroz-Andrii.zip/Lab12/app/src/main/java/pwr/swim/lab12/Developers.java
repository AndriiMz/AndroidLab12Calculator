package pwr.swim.lab12;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.GridView;

import common.MyAdapter;

public class Developers extends AppCompatActivity {
    private GridView grid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_developers);

        grid = (GridView) findViewById(R.id.gridView);
        grid.setAdapter(new MyAdapter(this));
    }



    /**
     * @param view
     */
    public void runSendSms(View view) {
        Intent sms = new Intent(Intent.ACTION_SENDTO,
                Uri.parse("sms:733913212"));
        sms.putExtra("sms_body", "Hello developer, im using your app!");
        startActivity(sms);
    }

    public void runShowGallery(View view) {
        Intent gallery = new Intent();
        gallery.setType("image/pictures/*");
        gallery.setAction(Intent.ACTION_GET_CONTENT);
        startActivity(gallery);
    }


    public void runBack(View view) {
        finish();
    }
}

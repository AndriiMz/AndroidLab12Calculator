package pwr.swim.lab12;

import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ConditionPolicyActivity extends AppCompatActivity implements ActionBar.TabListener  {

    ConditionFragment fCond;
    PolicyFragment fPol;
    FragmentTransaction transaction;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_condition_policy);

        fCond = new ConditionFragment();
        fPol = new PolicyFragment();
        transaction = getSupportFragmentManager().beginTransaction();
        transaction.add(R.id.conditionPolicyContainer, fCond);
        transaction.detach(fCond);
        transaction.add(R.id.conditionPolicyContainer, fPol);
        transaction.detach(fPol);
        transaction.commit();


        ActionBar bar = getSupportActionBar();
        bar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

        ActionBar.Tab tab;
        tab = bar.newTab();
        tab.setText("Conditions");
        tab.setTabListener(this);
        bar.addTab(tab);
        tab = bar.newTab();
        tab.setText("Policy");
        tab.setTabListener(this);
        bar.addTab(tab);

    }


    @Override
    public void onTabSelected(ActionBar.Tab tab, FragmentTransaction ft) {
        FragmentTransaction transact = getSupportFragmentManager().beginTransaction();
        switch (tab.getPosition()) {
            case 0:
                transact.attach(fCond);
                break;
            case 1:
                transact.attach(fPol);
                break;
            default:
                break;
        }
        transact.commit();
    }

    @Override
    public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction ft) {
        FragmentTransaction transact = getSupportFragmentManager().beginTransaction();
        switch (tab.getPosition()) {
            case 0:
                transact.detach(fCond);
                break;
            case 1:
                transact.detach(fPol);
                break;
            default:
                break;
        }
        transact.commit();
    }

    @Override
    public void onTabReselected(ActionBar.Tab tab, FragmentTransaction ft) {
    }
}

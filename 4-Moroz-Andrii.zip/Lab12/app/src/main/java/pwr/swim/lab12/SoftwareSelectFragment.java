package pwr.swim.lab12;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;


/**
 * A simple {@link Fragment} subclass.
 */
public class SoftwareSelectFragment extends Fragment implements android.widget.RadioGroup.OnCheckedChangeListener {
    public interface OnOptionSelect {
        public void onOptionSelect(int option);
    }
    AppCompatActivity activity;
    OnOptionSelect listener;


    public SoftwareSelectFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_software_select, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((RadioGroup)getActivity().findViewById(R.id.groupSoftwareSelect))
                .setOnCheckedChangeListener(this);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            activity = (AppCompatActivity) context;
            listener = (OnOptionSelect) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement interface OnOptionSelect");
        }
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        switch (i) {
            case R.id.radioButton11:
                listener.onOptionSelect(1);
                break;
            case R.id.radioButton12:
                listener.onOptionSelect(2);
                break;
            default:
                break;
        }
    }
}

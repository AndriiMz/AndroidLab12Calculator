package pwr.swim.lab12;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import common.LocalHistoryService;

public class History extends AppCompatActivity implements AdapterView.OnItemClickListener {
    private LocalHistoryService history;
    private ListView listHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        history = new LocalHistoryService(this);
        _readHistory();
    }


    protected void _readHistory() {
        String[] list = TextUtils.split(history.read(), ",");
        listHistory = findViewById(R.id.listView);
        listHistory.setOnItemClickListener(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                list
        );
        listHistory.setAdapter(adapter);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
    }
}

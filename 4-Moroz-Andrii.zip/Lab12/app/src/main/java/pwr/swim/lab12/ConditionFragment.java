package pwr.swim.lab12;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;

import common.SharedPreferencesService;


/**
 * A simple {@link Fragment} subclass.
 */
public class ConditionFragment extends Fragment {

    private SharedPreferencesService sp;
    private Switch sw;

    public ConditionFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        setRetainInstance(true);
        View view = inflater.inflate(
                R.layout.fragment_condition,
                container,
                false
        );
        sp = new SharedPreferencesService(this.getActivity());
        sw = (Switch) view.findViewById(R.id.switchConditions);
        sw.setChecked(sp.loadBoolean("switchConditions"));
        return view;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (null != sw) {
            sp.saveBoolean(sw.isChecked(), "switchConditions");
        }
    }
}

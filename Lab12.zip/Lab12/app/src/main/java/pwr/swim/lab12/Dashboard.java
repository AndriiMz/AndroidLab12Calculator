package pwr.swim.lab12;

import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.text.DecimalFormat;

import pwr.swim.lab12.databinding.ActivityDashboardBinding;

public class Dashboard extends AppCompatActivity {
    private static final char ADD = '+';
    private static final char SUB = '-';
    private static final char MUL = '*';
    private static final char DIV = '/';
    private char ACTION;

    private ActivityDashboardBinding binding;
    private DecimalFormat outputFormat;

    private double argument1 = Double.NaN;
    private double argument2;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_dashboard);
        outputFormat = new DecimalFormat("#.##########");

        bindNumberButtonClick(binding.buttonZero, "0");
        bindNumberButtonClick(binding.buttonOne, "1");
        bindNumberButtonClick(binding.buttonTwo, "2");
        bindNumberButtonClick(binding.buttonThree, "3");
        bindNumberButtonClick(binding.buttonFour, "4");
        bindNumberButtonClick(binding.buttonFive, "5");
        bindNumberButtonClick(binding.buttonSix, "6");
        bindNumberButtonClick(binding.buttonSeven, "7");
        bindNumberButtonClick(binding.buttonEight, "8");
        bindNumberButtonClick(binding.buttonNine, "9");

        bindActionButton(binding.buttonAdd, ADD);
        bindActionButton(binding.buttonSubtract, SUB);
        bindActionButton(binding.buttonMultiply, MUL);
        bindActionButton(binding.buttonDivide, DIV);

        binding.buttonEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                computeCalculation();
                binding.infoTextView.setText(binding.infoTextView.getText().toString() +
                        outputFormat.format(argument2) + " = " + outputFormat.format(argument1));
                argument1 = Double.NaN;
                ACTION = '0';
            }
        });

        binding.buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                argument1 = Double.NaN;
                argument2 = Double.NaN;
                binding.infoTextView.setText(null);
                binding.editText.setText(null);
                ACTION = '0';
            }
        });
    }

    protected void bindNumberButtonClick(Button button, final String additional) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + additional);
            }
        });
    }

    protected void bindActionButton(Button button, final char opertor) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                computeCalculation();
                ACTION = opertor;
                binding.infoTextView.setText(outputFormat.format(argument1) + opertor);
                binding.editText.setText(null);
            }
        });
    }

    private void computeCalculation() {
        if(!Double.isNaN(argument1)) {
            argument2 = Double.parseDouble(binding.editText.getText().toString());
            binding.editText.setText(null);

            if(ACTION == ADD)
                argument1 = this.argument1 + argument2;
            else if(ACTION == SUB)
                argument1 = this.argument1 - argument2;
            else if(ACTION == MUL)
                argument1 = this.argument1 * argument2;
            else if(ACTION == DIV)
                argument1 = this.argument1 / argument2;
        }
        else {
            try {
                argument1 = Double.parseDouble(binding.editText.getText().toString());
            }
            catch (Exception e){}
        }
    }
}
